﻿namespace QLVMB
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.txtdongho = new System.Windows.Forms.ToolStripLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menu_hethong = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_doimatkhau_hethong = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_thoat = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýSânBayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.máyBayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýLịchBayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hạngVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmVéChuyếnBayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNhậpXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoThôngKêLinhKiênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.traCứuThôngTinKháchHangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.traCứuVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel2,
            this.toolStripLabel3,
            this.txtdongho});
            this.toolStrip1.Location = new System.Drawing.Point(0, 466);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1164, 31);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(77, 28);
            this.toolStripLabel2.Text = "Xin chào : ";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(0, 28);
            // 
            // txtdongho
            // 
            this.txtdongho.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.txtdongho.Name = "txtdongho";
            this.txtdongho.Size = new System.Drawing.Size(44, 28);
            this.txtdongho.Text = "10:10";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_hethong,
            this.quảnLýToolStripMenuItem,
            this.toolStripMenuItem4,
            this.cậpNhậtToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1164, 30);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 30);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1164, 467);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // menu_hethong
            // 
            this.menu_hethong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.menu_doimatkhau_hethong,
            this.toolStripMenuItem3,
            this.menu_thoat});
            this.menu_hethong.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.menu_hethong.ForeColor = System.Drawing.Color.Red;
            this.menu_hethong.Image = global::QLVMB.Properties.Resources.Manager;
            this.menu_hethong.Name = "menu_hethong";
            this.menu_hethong.Size = new System.Drawing.Size(119, 26);
            this.menu_hethong.Text = "Hệ Thống";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.Blue;
            this.toolStripMenuItem2.Image = global::QLVMB.Properties.Resources.Employee;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(243, 26);
            this.toolStripMenuItem2.Text = "Quản Lý Nhân Viên";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.MenuNhanVien_Click);
            // 
            // menu_doimatkhau_hethong
            // 
            this.menu_doimatkhau_hethong.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.menu_doimatkhau_hethong.ForeColor = System.Drawing.Color.Blue;
            this.menu_doimatkhau_hethong.Image = ((System.Drawing.Image)(resources.GetObject("menu_doimatkhau_hethong.Image")));
            this.menu_doimatkhau_hethong.Name = "menu_doimatkhau_hethong";
            this.menu_doimatkhau_hethong.Size = new System.Drawing.Size(243, 26);
            this.menu_doimatkhau_hethong.Text = "Đổi mật khẩu";
            this.menu_doimatkhau_hethong.Click += new System.EventHandler(this.MenuDoiMatKhau_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem3.ForeColor = System.Drawing.Color.Blue;
            this.toolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem3.Image")));
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(243, 26);
            this.toolStripMenuItem3.Text = "Đăng xuất";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.MenuDangXuat_Click);
            // 
            // menu_thoat
            // 
            this.menu_thoat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.menu_thoat.ForeColor = System.Drawing.Color.Blue;
            this.menu_thoat.Image = ((System.Drawing.Image)(resources.GetObject("menu_thoat.Image")));
            this.menu_thoat.Name = "menu_thoat";
            this.menu_thoat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.menu_thoat.Size = new System.Drawing.Size(243, 26);
            this.menu_thoat.Text = "Thoát";
            this.menu_thoat.Click += new System.EventHandler(this.MenuThoat_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýSânBayToolStripMenuItem,
            this.quảnLýToolStripMenuItem1,
            this.máyBayToolStripMenuItem,
            this.quảnLýLịchBayToolStripMenuItem,
            this.hạngVéToolStripMenuItem,
            this.thêmVéChuyếnBayToolStripMenuItem,
            this.quảnLýKháchHàngToolStripMenuItem,
            this.quảnLýNhậpXuấtToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.quảnLýToolStripMenuItem.Image = global::QLVMB.Properties.Resources.Device_Manager;
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(109, 26);
            this.quảnLýToolStripMenuItem.Text = "Quản Lý";
            // 
            // quảnLýSânBayToolStripMenuItem
            // 
            this.quảnLýSânBayToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.quảnLýSânBayToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýSânBayToolStripMenuItem.Image")));
            this.quảnLýSânBayToolStripMenuItem.Name = "quảnLýSânBayToolStripMenuItem";
            this.quảnLýSânBayToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.quảnLýSânBayToolStripMenuItem.Text = "Quản lý sân bay";
            this.quảnLýSânBayToolStripMenuItem.Click += new System.EventHandler(this.MenuSanBay_Click);
            // 
            // quảnLýToolStripMenuItem1
            // 
            this.quảnLýToolStripMenuItem1.ForeColor = System.Drawing.Color.Blue;
            this.quảnLýToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýToolStripMenuItem1.Image")));
            this.quảnLýToolStripMenuItem1.Name = "quảnLýToolStripMenuItem1";
            this.quảnLýToolStripMenuItem1.Size = new System.Drawing.Size(248, 26);
            this.quảnLýToolStripMenuItem1.Text = "Quản lý tuyến  bay";
            this.quảnLýToolStripMenuItem1.Click += new System.EventHandler(this.MenuTuyenBay_Click);
            // 
            // máyBayToolStripMenuItem
            // 
            this.máyBayToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.máyBayToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("máyBayToolStripMenuItem.Image")));
            this.máyBayToolStripMenuItem.Name = "máyBayToolStripMenuItem";
            this.máyBayToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.máyBayToolStripMenuItem.Text = "Quản lý máy bay";
            this.máyBayToolStripMenuItem.Click += new System.EventHandler(this.máyBayToolStripMenuItem_Click);
            // 
            // quảnLýLịchBayToolStripMenuItem
            // 
            this.quảnLýLịchBayToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.quảnLýLịchBayToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýLịchBayToolStripMenuItem.Image")));
            this.quảnLýLịchBayToolStripMenuItem.Name = "quảnLýLịchBayToolStripMenuItem";
            this.quảnLýLịchBayToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.quảnLýLịchBayToolStripMenuItem.Text = "Quản lý lịch bay";
            this.quảnLýLịchBayToolStripMenuItem.Click += new System.EventHandler(this.quảnLýLịchBayToolStripMenuItem_Click);
            // 
            // hạngVéToolStripMenuItem
            // 
            this.hạngVéToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.hạngVéToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hạngVéToolStripMenuItem.Image")));
            this.hạngVéToolStripMenuItem.Name = "hạngVéToolStripMenuItem";
            this.hạngVéToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.hạngVéToolStripMenuItem.Text = "Quản lý hạng vé";
            this.hạngVéToolStripMenuItem.Click += new System.EventHandler(this.hạngVéToolStripMenuItem_Click);
            // 
            // thêmVéChuyếnBayToolStripMenuItem
            // 
            this.thêmVéChuyếnBayToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.thêmVéChuyếnBayToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thêmVéChuyếnBayToolStripMenuItem.Image")));
            this.thêmVéChuyếnBayToolStripMenuItem.Name = "thêmVéChuyếnBayToolStripMenuItem";
            this.thêmVéChuyếnBayToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.thêmVéChuyếnBayToolStripMenuItem.Text = "Quản lý giá vé";
            this.thêmVéChuyếnBayToolStripMenuItem.Click += new System.EventHandler(this.MenuGiaVeChuyenBay_Click);
            // 
            // quảnLýKháchHàngToolStripMenuItem
            // 
            this.quảnLýKháchHàngToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.quảnLýKháchHàngToolStripMenuItem.Image = global::QLVMB.Properties.Resources.Customer;
            this.quảnLýKháchHàngToolStripMenuItem.Name = "quảnLýKháchHàngToolStripMenuItem";
            this.quảnLýKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.quảnLýKháchHàngToolStripMenuItem.Text = "Quản lý khách hàng";
            this.quảnLýKháchHàngToolStripMenuItem.Click += new System.EventHandler(this.MenuQuanLyHangKhach_Click);
            // 
            // quảnLýNhậpXuấtToolStripMenuItem
            // 
            this.quảnLýNhậpXuấtToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.quảnLýNhậpXuấtToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýNhậpXuấtToolStripMenuItem.Image")));
            this.quảnLýNhậpXuấtToolStripMenuItem.Name = "quảnLýNhậpXuấtToolStripMenuItem";
            this.quảnLýNhậpXuấtToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.quảnLýNhậpXuấtToolStripMenuItem.Text = "Quản lý đặt chỗ";
            this.quảnLýNhậpXuấtToolStripMenuItem.Click += new System.EventHandler(this.MenuDatCho_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.báoCáoThôngKêLinhKiênToolStripMenuItem});
            this.toolStripMenuItem4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.toolStripMenuItem4.Image = global::QLVMB.Properties.Resources.Doughnut_Chart;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(110, 26);
            this.toolStripMenuItem4.Text = "Báo Cáo";
            // 
            // báoCáoThôngKêLinhKiênToolStripMenuItem
            // 
            this.báoCáoThôngKêLinhKiênToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.báoCáoThôngKêLinhKiênToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("báoCáoThôngKêLinhKiênToolStripMenuItem.Image")));
            this.báoCáoThôngKêLinhKiênToolStripMenuItem.Name = "báoCáoThôngKêLinhKiênToolStripMenuItem";
            this.báoCáoThôngKêLinhKiênToolStripMenuItem.Size = new System.Drawing.Size(281, 26);
            this.báoCáoThôngKêLinhKiênToolStripMenuItem.Text = "Doanh thu bán vé tháng";
            this.báoCáoThôngKêLinhKiênToolStripMenuItem.Click += new System.EventHandler(this.MenuDoanhThu_Click);
            // 
            // cậpNhậtToolStripMenuItem
            // 
            this.cậpNhậtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hóaĐơnToolStripMenuItem,
            this.traCứuThôngTinKháchHangToolStripMenuItem,
            this.traCứuVéToolStripMenuItem});
            this.cậpNhậtToolStripMenuItem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cậpNhậtToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.cậpNhậtToolStripMenuItem.Image = global::QLVMB.Properties.Resources.Search;
            this.cậpNhậtToolStripMenuItem.Name = "cậpNhậtToolStripMenuItem";
            this.cậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(115, 26);
            this.cậpNhậtToolStripMenuItem.Text = "Tìm Kiếm";
            // 
            // hóaĐơnToolStripMenuItem
            // 
            this.hóaĐơnToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.hóaĐơnToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hóaĐơnToolStripMenuItem.Image")));
            this.hóaĐơnToolStripMenuItem.Name = "hóaĐơnToolStripMenuItem";
            this.hóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.hóaĐơnToolStripMenuItem.Text = "Tra cứu thông tin chuyến bay";
            this.hóaĐơnToolStripMenuItem.Click += new System.EventHandler(this.MenuTraCuu_Click);
            // 
            // traCứuThôngTinKháchHangToolStripMenuItem
            // 
            this.traCứuThôngTinKháchHangToolStripMenuItem.Name = "traCứuThôngTinKháchHangToolStripMenuItem";
            this.traCứuThôngTinKháchHangToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.traCứuThôngTinKháchHangToolStripMenuItem.Text = "Tra cứu thông tin khách hàng";
            // 
            // traCứuVéToolStripMenuItem
            // 
            this.traCứuVéToolStripMenuItem.Name = "traCứuVéToolStripMenuItem";
            this.traCứuVéToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.traCứuVéToolStripMenuItem.Text = "Tra cứu vé chuyến bay";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 497);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Bán Vé Máy Bay";
            this.Load += new System.EventHandler(this.frm_Main_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem quảnLýSânBayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem báoCáoThôngKêLinhKiênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem traCứuThôngTinKháchHangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem traCứuVéToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripLabel txtdongho;
        private System.Windows.Forms.ToolStripMenuItem quảnLýKháchHàngToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem thêmVéChuyếnBayToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menu_hethong;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem menu_doimatkhau_hethong;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem menu_thoat;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNhậpXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýLịchBayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hạngVéToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem máyBayToolStripMenuItem;
    }
}