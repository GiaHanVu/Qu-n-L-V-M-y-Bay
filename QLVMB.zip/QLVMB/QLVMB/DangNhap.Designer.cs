﻿namespace QLVMB
{
    partial class DangNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DangNhap));
            this.gbthongtindangnhap = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btthoat = new System.Windows.Forms.Button();
            this.btdanhnhap = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbid = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbdn = new System.Windows.Forms.Label();
            this.gbthongtindangnhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gbthongtindangnhap
            // 
            this.gbthongtindangnhap.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbthongtindangnhap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gbthongtindangnhap.BackgroundImage = global::QLVMB.Properties.Resources.bay;
            this.gbthongtindangnhap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gbthongtindangnhap.Controls.Add(this.pictureBox1);
            this.gbthongtindangnhap.Controls.Add(this.btthoat);
            this.gbthongtindangnhap.Controls.Add(this.btdanhnhap);
            this.gbthongtindangnhap.Controls.Add(this.textBox2);
            this.gbthongtindangnhap.Controls.Add(this.lbid);
            this.gbthongtindangnhap.Controls.Add(this.textBox1);
            this.gbthongtindangnhap.Controls.Add(this.lbdn);
            this.gbthongtindangnhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbthongtindangnhap.ForeColor = System.Drawing.Color.Red;
            this.gbthongtindangnhap.Location = new System.Drawing.Point(8, 14);
            this.gbthongtindangnhap.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gbthongtindangnhap.Name = "gbthongtindangnhap";
            this.gbthongtindangnhap.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gbthongtindangnhap.Size = new System.Drawing.Size(486, 361);
            this.gbthongtindangnhap.TabIndex = 1;
            this.gbthongtindangnhap.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::QLVMB.Properties.Resources.R;
            this.pictureBox1.Location = new System.Drawing.Point(108, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(295, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btthoat
            // 
            this.btthoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btthoat.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btthoat.ForeColor = System.Drawing.Color.Black;
            this.btthoat.Image = ((System.Drawing.Image)(resources.GetObject("btthoat.Image")));
            this.btthoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btthoat.Location = new System.Drawing.Point(293, 279);
            this.btthoat.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(110, 50);
            this.btthoat.TabIndex = 5;
            this.btthoat.Text = "Thoát";
            this.btthoat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btthoat.UseVisualStyleBackColor = false;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // btdanhnhap
            // 
            this.btdanhnhap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btdanhnhap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btdanhnhap.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btdanhnhap.ForeColor = System.Drawing.Color.Black;
            this.btdanhnhap.Image = global::QLVMB.Properties.Resources.Login;
            this.btdanhnhap.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btdanhnhap.Location = new System.Drawing.Point(71, 279);
            this.btdanhnhap.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btdanhnhap.Name = "btdanhnhap";
            this.btdanhnhap.Size = new System.Drawing.Size(169, 50);
            this.btdanhnhap.TabIndex = 3;
            this.btdanhnhap.Text = "Đăng Nhập";
            this.btdanhnhap.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btdanhnhap.UseVisualStyleBackColor = false;
            this.btdanhnhap.Click += new System.EventHandler(this.btdanhnhap_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(210, 219);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(246, 28);
            this.textBox2.TabIndex = 2;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.textBox2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox2_KeyUp);
            // 
            // lbid
            // 
            this.lbid.AutoSize = true;
            this.lbid.BackColor = System.Drawing.Color.Transparent;
            this.lbid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbid.ForeColor = System.Drawing.Color.Black;
            this.lbid.Location = new System.Drawing.Point(38, 224);
            this.lbid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbid.Name = "lbid";
            this.lbid.Size = new System.Drawing.Size(138, 20);
            this.lbid.TabIndex = 0;
            this.lbid.Text = "Mã Đăng Nhập:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(210, 160);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(246, 28);
            this.textBox1.TabIndex = 1;
            this.textBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyUp);
            // 
            // lbdn
            // 
            this.lbdn.AutoSize = true;
            this.lbdn.BackColor = System.Drawing.Color.Transparent;
            this.lbdn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbdn.ForeColor = System.Drawing.Color.Black;
            this.lbdn.Location = new System.Drawing.Point(38, 169);
            this.lbdn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbdn.Name = "lbdn";
            this.lbdn.Size = new System.Drawing.Size(144, 20);
            this.lbdn.TabIndex = 0;
            this.lbdn.Text = "Tên Đăng Nhập:";
            // 
            // DangNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 390);
            this.Controls.Add(this.gbthongtindangnhap);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "DangNhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập";
            this.Load += new System.EventHandler(this.DangNhap_Load);
            this.gbthongtindangnhap.ResumeLayout(false);
            this.gbthongtindangnhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbthongtindangnhap;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.Button btdanhnhap;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbid;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbdn;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

