﻿namespace QLVMB
{
    partial class DatCho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_2 = new System.Windows.Forms.ComboBox();
            this.txt_8 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_5 = new System.Windows.Forms.TextBox();
            this.txt_4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_2 = new System.Windows.Forms.TextBox();
            this.txt_1 = new System.Windows.Forms.TextBox();
            this.cb_1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.bnt_thoat = new System.Windows.Forms.Button();
            this.bnt_taomoi = new System.Windows.Forms.Button();
            this.bnt_luu = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bnt_1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.AllowDrop = true;
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.dateTimePicker1.CustomFormat = "hh:mm:ss  MM/dd/ yyyy";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(215, 458);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 31);
            this.dateTimePicker1.TabIndex = 110;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.textBox10.Location = new System.Drawing.Point(215, 397);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(256, 35);
            this.textBox10.TabIndex = 109;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(51, 408);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 15);
            this.label1.TabIndex = 108;
            this.label1.Text = "Giá Tiền:";
            // 
            // cb_2
            // 
            this.cb_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.cb_2.FormattingEnabled = true;
            this.cb_2.Location = new System.Drawing.Point(215, 336);
            this.cb_2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cb_2.Name = "cb_2";
            this.cb_2.Size = new System.Drawing.Size(256, 33);
            this.cb_2.TabIndex = 107;
            this.cb_2.SelectedIndexChanged += new System.EventHandler(this.cb_2_SelectedIndexChanged);
            // 
            // txt_8
            // 
            this.txt_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_8.Location = new System.Drawing.Point(651, 278);
            this.txt_8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_8.Multiline = true;
            this.txt_8.Name = "txt_8";
            this.txt_8.Size = new System.Drawing.Size(259, 34);
            this.txt_8.TabIndex = 105;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(507, 286);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 15);
            this.label9.TabIndex = 104;
            this.label9.Text = "Điện Thoại:";
            // 
            // txt_7
            // 
            this.txt_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_7.Location = new System.Drawing.Point(215, 278);
            this.txt_7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_7.Multiline = true;
            this.txt_7.Name = "txt_7";
            this.txt_7.Size = new System.Drawing.Size(256, 34);
            this.txt_7.TabIndex = 103;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Navy;
            this.label8.Location = new System.Drawing.Point(51, 232);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 15);
            this.label8.TabIndex = 102;
            this.label8.Text = "Mã Hành Khách:";
            // 
            // txt_6
            // 
            this.txt_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_6.Location = new System.Drawing.Point(651, 224);
            this.txt_6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_6.Multiline = true;
            this.txt_6.Name = "txt_6";
            this.txt_6.Size = new System.Drawing.Size(259, 34);
            this.txt_6.TabIndex = 101;
            this.txt_6.TextChanged += new System.EventHandler(this.txt_6_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(507, 232);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 15);
            this.label7.TabIndex = 100;
            this.label7.Text = "CMND:";
            // 
            // txt_5
            // 
            this.txt_5.BackColor = System.Drawing.Color.White;
            this.txt_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_5.Location = new System.Drawing.Point(215, 224);
            this.txt_5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_5.Multiline = true;
            this.txt_5.Name = "txt_5";
            this.txt_5.Size = new System.Drawing.Size(256, 34);
            this.txt_5.TabIndex = 99;
            this.txt_5.TextChanged += new System.EventHandler(this.txt_5_TextChanged);
            // 
            // txt_4
            // 
            this.txt_4.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_4.Location = new System.Drawing.Point(651, 172);
            this.txt_4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_4.Multiline = true;
            this.txt_4.Name = "txt_4";
            this.txt_4.ReadOnly = true;
            this.txt_4.Size = new System.Drawing.Size(259, 34);
            this.txt_4.TabIndex = 97;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(504, 180);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 15);
            this.label6.TabIndex = 96;
            this.label6.Text = "Tình Trạng Vé:";
            // 
            // txt_3
            // 
            this.txt_3.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_3.Location = new System.Drawing.Point(215, 172);
            this.txt_3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_3.Multiline = true;
            this.txt_3.Name = "txt_3";
            this.txt_3.ReadOnly = true;
            this.txt_3.Size = new System.Drawing.Size(256, 34);
            this.txt_3.TabIndex = 95;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(51, 180);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 15);
            this.label5.TabIndex = 94;
            this.label5.Text = "Ngày Giờ:";
            // 
            // txt_2
            // 
            this.txt_2.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_2.Location = new System.Drawing.Point(651, 114);
            this.txt_2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_2.Multiline = true;
            this.txt_2.Name = "txt_2";
            this.txt_2.ReadOnly = true;
            this.txt_2.Size = new System.Drawing.Size(259, 34);
            this.txt_2.TabIndex = 93;
            // 
            // txt_1
            // 
            this.txt_1.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_1.Location = new System.Drawing.Point(215, 114);
            this.txt_1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_1.Multiline = true;
            this.txt_1.Name = "txt_1";
            this.txt_1.ReadOnly = true;
            this.txt_1.Size = new System.Drawing.Size(256, 34);
            this.txt_1.TabIndex = 91;
            // 
            // cb_1
            // 
            this.cb_1.DropDownHeight = 123;
            this.cb_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.75F);
            this.cb_1.FormattingEnabled = true;
            this.cb_1.IntegralHeight = false;
            this.cb_1.ItemHeight = 25;
            this.cb_1.Items.AddRange(new object[] {
            "---Chọn chuyến bay--"});
            this.cb_1.Location = new System.Drawing.Point(215, 57);
            this.cb_1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cb_1.Name = "cb_1";
            this.cb_1.Size = new System.Drawing.Size(256, 33);
            this.cb_1.TabIndex = 89;
            this.cb_1.SelectedIndexChanged += new System.EventHandler(this.cb_1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(51, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 15);
            this.label2.TabIndex = 88;
            this.label2.Text = "Mã Chuyến Bay:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Purple;
            this.label11.Location = new System.Drawing.Point(363, 21);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(180, 25);
            this.label11.TabIndex = 87;
            this.label11.Text = "PHIẾU ĐẶT CHỖ";
            // 
            // bnt_thoat
            // 
            this.bnt_thoat.Location = new System.Drawing.Point(727, 563);
            this.bnt_thoat.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.bnt_thoat.Name = "bnt_thoat";
            this.bnt_thoat.Size = new System.Drawing.Size(133, 32);
            this.bnt_thoat.TabIndex = 86;
            this.bnt_thoat.Text = "Thoát";
            this.bnt_thoat.UseVisualStyleBackColor = true;
            this.bnt_thoat.Click += new System.EventHandler(this.bnt_thoat_Click);
            // 
            // bnt_taomoi
            // 
            this.bnt_taomoi.Location = new System.Drawing.Point(552, 563);
            this.bnt_taomoi.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.bnt_taomoi.Name = "bnt_taomoi";
            this.bnt_taomoi.Size = new System.Drawing.Size(133, 32);
            this.bnt_taomoi.TabIndex = 85;
            this.bnt_taomoi.Text = "Tạo Mới";
            this.bnt_taomoi.UseVisualStyleBackColor = true;
            this.bnt_taomoi.Click += new System.EventHandler(this.bnt_taomoi_Click);
            // 
            // bnt_luu
            // 
            this.bnt_luu.Location = new System.Drawing.Point(172, 563);
            this.bnt_luu.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.bnt_luu.Name = "bnt_luu";
            this.bnt_luu.Size = new System.Drawing.Size(133, 32);
            this.bnt_luu.TabIndex = 84;
            this.bnt_luu.Text = "Thêm";
            this.bnt_luu.UseVisualStyleBackColor = true;
            this.bnt_luu.Click += new System.EventHandler(this.bnt_luu_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Navy;
            this.label10.Location = new System.Drawing.Point(51, 470);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 15);
            this.label10.TabIndex = 83;
            this.label10.Text = "Ngày Đặt:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Navy;
            this.label12.Location = new System.Drawing.Point(51, 286);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 15);
            this.label12.TabIndex = 102;
            this.label12.Text = "Tên Hành Khách:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Navy;
            this.label13.Location = new System.Drawing.Point(51, 345);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 15);
            this.label13.TabIndex = 102;
            this.label13.Text = "Hạng vé:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(511, 336);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(400, 173);
            this.dataGridView1.TabIndex = 111;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(368, 563);
            this.button1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 32);
            this.button1.TabIndex = 85;
            this.button1.Text = "Xóa";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.bnt_xoa_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(507, 122);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 15);
            this.label3.TabIndex = 112;
            this.label3.Text = "Sân Bay Đến:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(51, 122);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 15);
            this.label4.TabIndex = 113;
            this.label4.Text = "Sân Bay Đi:";
            // 
            // bnt_1
            // 
            this.bnt_1.ForeColor = System.Drawing.Color.Black;
            this.bnt_1.Location = new System.Drawing.Point(55, 223);
            this.bnt_1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bnt_1.Name = "bnt_1";
            this.bnt_1.Size = new System.Drawing.Size(137, 32);
            this.bnt_1.TabIndex = 114;
            this.bnt_1.Text = "Mã Hành Khách:";
            this.bnt_1.UseVisualStyleBackColor = true;
            this.bnt_1.Click += new System.EventHandler(this.bnt_1_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(55, 337);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 30);
            this.button2.TabIndex = 115;
            this.button2.Text = "Hạng Vé:";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(55, 403);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 27);
            this.button3.TabIndex = 116;
            this.button3.Text = "Giá tiền:";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // DatCho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 628);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.bnt_1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_2);
            this.Controls.Add(this.txt_8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_7);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_5);
            this.Controls.Add(this.txt_4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_2);
            this.Controls.Add(this.txt_1);
            this.Controls.Add(this.cb_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.bnt_thoat);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bnt_taomoi);
            this.Controls.Add(this.bnt_luu);
            this.Controls.Add(this.label10);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "DatCho";
            this.Text = "Đặt Chỗ ";
            this.Load += new System.EventHandler(this.DatCho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_2;
        private System.Windows.Forms.TextBox txt_8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_5;
        private System.Windows.Forms.TextBox txt_4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_2;
        private System.Windows.Forms.TextBox txt_1;
        private System.Windows.Forms.ComboBox cb_1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bnt_thoat;
        private System.Windows.Forms.Button bnt_taomoi;
        private System.Windows.Forms.Button bnt_luu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bnt_1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}