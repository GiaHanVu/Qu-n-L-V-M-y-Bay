﻿namespace QLVMB
{
    partial class VeChuyenBay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bnt_4 = new System.Windows.Forms.Button();
            this.bnt_3 = new System.Windows.Forms.Button();
            this.bnt_2 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cb_2 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_8 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_5 = new System.Windows.Forms.TextBox();
            this.bnt_1 = new System.Windows.Forms.Button();
            this.txt_4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bnt_4
            // 
            this.bnt_4.ForeColor = System.Drawing.Color.Black;
            this.bnt_4.Location = new System.Drawing.Point(469, 424);
            this.bnt_4.Name = "bnt_4";
            this.bnt_4.Size = new System.Drawing.Size(112, 33);
            this.bnt_4.TabIndex = 52;
            this.bnt_4.Text = "Thoát";
            this.bnt_4.UseVisualStyleBackColor = true;
            this.bnt_4.Click += new System.EventHandler(this.bnt_4_Click);
            // 
            // bnt_3
            // 
            this.bnt_3.ForeColor = System.Drawing.Color.Black;
            this.bnt_3.Location = new System.Drawing.Point(273, 424);
            this.bnt_3.Name = "bnt_3";
            this.bnt_3.Size = new System.Drawing.Size(110, 33);
            this.bnt_3.TabIndex = 51;
            this.bnt_3.Text = "Tạo Mới";
            this.bnt_3.UseVisualStyleBackColor = true;
            // 
            // bnt_2
            // 
            this.bnt_2.ForeColor = System.Drawing.Color.Black;
            this.bnt_2.Location = new System.Drawing.Point(70, 424);
            this.bnt_2.Name = "bnt_2";
            this.bnt_2.Size = new System.Drawing.Size(116, 33);
            this.bnt_2.TabIndex = 50;
            this.bnt_2.Text = "Lưu";
            this.bnt_2.UseVisualStyleBackColor = true;
            this.bnt_2.Click += new System.EventHandler(this.bnt_2_Click);
            // 
            // textBox10
            // 
            this.textBox10.ForeColor = System.Drawing.Color.Black;
            this.textBox10.Location = new System.Drawing.Point(145, 363);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(193, 31);
            this.textBox10.TabIndex = 49;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(22, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 48;
            this.label10.Text = "Giá Tiền:";
            // 
            // cb_2
            // 
            this.cb_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.cb_2.ForeColor = System.Drawing.Color.Black;
            this.cb_2.FormattingEnabled = true;
            this.cb_2.Location = new System.Drawing.Point(144, 313);
            this.cb_2.Name = "cb_2";
            this.cb_2.Size = new System.Drawing.Size(193, 28);
            this.cb_2.TabIndex = 47;
            this.cb_2.SelectedIndexChanged += new System.EventHandler(this.cb_2_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(22, 310);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(113, 34);
            this.button2.TabIndex = 46;
            this.button2.Text = "Hạng Vé";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txt_8
            // 
            this.txt_8.ForeColor = System.Drawing.Color.Black;
            this.txt_8.Location = new System.Drawing.Point(472, 260);
            this.txt_8.Multiline = true;
            this.txt_8.Name = "txt_8";
            this.txt_8.ReadOnly = true;
            this.txt_8.Size = new System.Drawing.Size(195, 30);
            this.txt_8.TabIndex = 45;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(359, 263);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 44;
            this.label9.Text = "Điện Thoại:";
            // 
            // txt_7
            // 
            this.txt_7.ForeColor = System.Drawing.Color.Black;
            this.txt_7.Location = new System.Drawing.Point(145, 260);
            this.txt_7.Multiline = true;
            this.txt_7.Name = "txt_7";
            this.txt_7.ReadOnly = true;
            this.txt_7.Size = new System.Drawing.Size(193, 30);
            this.txt_7.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(22, 263);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Tên Hành Khách:";
            // 
            // txt_6
            // 
            this.txt_6.ForeColor = System.Drawing.Color.Black;
            this.txt_6.Location = new System.Drawing.Point(472, 214);
            this.txt_6.Multiline = true;
            this.txt_6.Name = "txt_6";
            this.txt_6.ReadOnly = true;
            this.txt_6.Size = new System.Drawing.Size(195, 30);
            this.txt_6.TabIndex = 41;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(359, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "CMND:";
            // 
            // txt_5
            // 
            this.txt_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_5.ForeColor = System.Drawing.Color.Black;
            this.txt_5.Location = new System.Drawing.Point(145, 214);
            this.txt_5.Multiline = true;
            this.txt_5.Name = "txt_5";
            this.txt_5.ReadOnly = true;
            this.txt_5.Size = new System.Drawing.Size(193, 30);
            this.txt_5.TabIndex = 39;
            // 
            // bnt_1
            // 
            this.bnt_1.ForeColor = System.Drawing.Color.Black;
            this.bnt_1.Location = new System.Drawing.Point(19, 210);
            this.bnt_1.Name = "bnt_1";
            this.bnt_1.Size = new System.Drawing.Size(116, 34);
            this.bnt_1.TabIndex = 38;
            this.bnt_1.Text = "Mã Hành Khách";
            this.bnt_1.UseVisualStyleBackColor = true;
            this.bnt_1.Click += new System.EventHandler(this.bnt_1_Click);
            // 
            // txt_4
            // 
            this.txt_4.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_4.ForeColor = System.Drawing.Color.Black;
            this.txt_4.Location = new System.Drawing.Point(472, 168);
            this.txt_4.Multiline = true;
            this.txt_4.Name = "txt_4";
            this.txt_4.ReadOnly = true;
            this.txt_4.Size = new System.Drawing.Size(195, 30);
            this.txt_4.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(359, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 36;
            this.label6.Text = "Tình Trạng Vé:";
            // 
            // txt_3
            // 
            this.txt_3.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_3.ForeColor = System.Drawing.Color.Black;
            this.txt_3.Location = new System.Drawing.Point(145, 168);
            this.txt_3.Multiline = true;
            this.txt_3.Name = "txt_3";
            this.txt_3.ReadOnly = true;
            this.txt_3.Size = new System.Drawing.Size(193, 30);
            this.txt_3.TabIndex = 35;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(22, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Ngày Giờ:";
            // 
            // txt_2
            // 
            this.txt_2.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_2.ForeColor = System.Drawing.Color.Black;
            this.txt_2.Location = new System.Drawing.Point(472, 118);
            this.txt_2.Multiline = true;
            this.txt_2.Name = "txt_2";
            this.txt_2.ReadOnly = true;
            this.txt_2.Size = new System.Drawing.Size(195, 30);
            this.txt_2.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(359, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "Sân Bay Đến:";
            // 
            // txt_1
            // 
            this.txt_1.BackColor = System.Drawing.Color.LemonChiffon;
            this.txt_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.75F);
            this.txt_1.ForeColor = System.Drawing.Color.Black;
            this.txt_1.Location = new System.Drawing.Point(145, 118);
            this.txt_1.Multiline = true;
            this.txt_1.Name = "txt_1";
            this.txt_1.ReadOnly = true;
            this.txt_1.Size = new System.Drawing.Size(193, 30);
            this.txt_1.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(22, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Sân Bay Đi:";
            // 
            // cb_1
            // 
            this.cb_1.DropDownHeight = 123;
            this.cb_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.75F);
            this.cb_1.ForeColor = System.Drawing.Color.Black;
            this.cb_1.FormattingEnabled = true;
            this.cb_1.IntegralHeight = false;
            this.cb_1.ItemHeight = 20;
            this.cb_1.Location = new System.Drawing.Point(145, 68);
            this.cb_1.Name = "cb_1";
            this.cb_1.Size = new System.Drawing.Size(193, 28);
            this.cb_1.TabIndex = 29;
            this.cb_1.SelectedIndexChanged += new System.EventHandler(this.cb_1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(22, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Mã Chuyến Bay:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(250, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 20);
            this.label1.TabIndex = 27;
            this.label1.Text = "VÉ CHUYẾN BAY";
            // 
            // VeChuyenBay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 468);
            this.Controls.Add(this.bnt_4);
            this.Controls.Add(this.bnt_3);
            this.Controls.Add(this.bnt_2);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cb_2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txt_8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_5);
            this.Controls.Add(this.bnt_1);
            this.Controls.Add(this.txt_4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cb_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "VeChuyenBay";
            this.Text = "Vé Chuyến Bay";
            this.Load += new System.EventHandler(this.frm_VeChuyenBay_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bnt_4;
        private System.Windows.Forms.Button bnt_3;
        private System.Windows.Forms.Button bnt_2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cb_2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_5;
        private System.Windows.Forms.Button bnt_1;
        private System.Windows.Forms.TextBox txt_4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}